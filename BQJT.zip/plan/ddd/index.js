(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control8_w3uOmg: function (elem) {
      if (!elem) {
        return;
      }return "财务工业增加值月报";
    },
    doAction_uiControl0_lsg728: function (data, elem) {
      if (data.eventType == 'click') {
        var target = elem.ownerDocument.querySelector("td[title='CWGYZJZYB001|财务工业增加值月报']"); //console.log(target);
        var doc = target.ownerDocument;var win = doc.defaultView;var evtOver = new win.MouseEvent("mouseover", { bubbles: true, cancelable: true, view: win });var evtFocus = new win.MouseEvent("focus", { bubbles: true, cancelable: true, view: win });var evtDown = new win.MouseEvent("mousedown", { bubbles: true, cancelable: true, view: win });var evtUp = new win.MouseEvent("mouseup", { bubbles: true, cancelable: true, view: win });var evtOut = new win.MouseEvent("mouseout", { bubbles: true, cancelable: true, view: win });target.dispatchEvent(evtOver);target.dispatchEvent(evtFocus);target.dispatchEvent(evtDown);target.dispatchEvent(evtUp);target.dispatchEvent(evtOut);
      }
    },
    getTemplate_uiControl0_lsg728: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onclick:function(e){\n    var handler=this.props.customHandler;\n    var target=e.target;\n    if(handler){\n      handler({\n        eventType:'click'\n      })\n    }\n  },\n  render: function() {\n    return (\n      <div className='primeBtn'>\n        <button onClick={this.onclick}>{this.props.customData}</button>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  onclick: function onclick(e) {\n    var handler = this.props.customHandler;\n    var target = e.target;\n    if (handler) {\n      handler({\n        eventType: 'click'\n      });\n    }\n  },\n  render: function render() {\n    return React.createElement(\n      'div',\n      { className: 'primeBtn' },\n      React.createElement(\n        'button',\n        { onClick: this.onclick },\n        this.props.customData\n      )\n    );\n  }\n});";
    }
  }, "ddd");
})(window, ysp);