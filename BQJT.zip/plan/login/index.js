(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control3_V94CHU: function (elem) {
      return true;
    },
    doAction_uiControl3_XPp4g1: function (data, elem) {
      //debugger;
      $(elem).val(data.dataCustom); /*$(elem).trigger('input');
                                    $(elem).change();
                                    $(elem.ownerDocument).keydown();
                                    $(elem.ownerDocument).keyup();*/elem.dispatchEvent(new Event('input'));
    },
    getTemplate_uiControl3_XPp4g1: function () {
      var selfTemplate = "module.exports = React.createClass({\n  blur:function(e){\n    this.props.customHandler({\n      eventType:'blur',\n      data:e.target.value\n    })\n  },\n  render: function() {\n    return (\n      <div className='userName'>\n        <span>\u7528\u6237\u540D</span>\n        <input type=\"text\" onBlur={this.blur}></input>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  blur: function blur(e) {\n    this.props.customHandler({\n      eventType: 'blur',\n      data: e.target.value\n    });\n  },\n  render: function render() {\n    return React.createElement(\n      'div',\n      { className: 'userName' },\n      React.createElement(\n        'span',\n        null,\n        '\\u7528\\u6237\\u540D'\n      ),\n      React.createElement('input', { type: 'text', onBlur: this.blur })\n    );\n  }\n});";
    },
    getData_control4_uW8RTz: function (elem) {
      return true;
    },
    doAction_uiControl4_3UaH8u: function (data, elem) {
      if (data.eventType == 'blur') {
        var evt = new MouseEvent('mousedown', { 'view': elem.ownerDocument.defaultView, 'bubbles': true, 'cancelabel': true });elem.dispatchEvent(evt);elem.dispatchEvent(new elem.ownerDocument.defaultView.Event('input'));$(elem).val(data.dataCustom);elem.dispatchEvent(new elem.ownerDocument.defaultView.Event('input'));
      }
    },
    getTemplate_uiControl4_3UaH8u: function () {
      var selfTemplate = "module.exports = React.createClass({\n  blur:function(e){\n    this.props.customHandler({\n      eventType:'blur',\n      data:e.target.value\n    })\n  },\n  render: function() {\n    return (\n      <div className='passWord'>\n        <span>\u5BC6\u7801</span>\n        <input type=\"password\" onBlur={this.blur}></input>\n      </div>\n    )\n  }\n});";
      return "'use strict';\n\nmodule.exports = React.createClass({\n  displayName: 'exports',\n\n  blur: function blur(e) {\n    this.props.customHandler({\n      eventType: 'blur',\n      data: e.target.value\n    });\n  },\n  render: function render() {\n    return React.createElement(\n      'div',\n      { className: 'passWord' },\n      React.createElement(\n        'span',\n        null,\n        '\\u5BC6\\u7801'\n      ),\n      React.createElement('input', { type: 'password', onBlur: this.blur })\n    );\n  }\n});";
    }
  }, "login");
})(window, ysp);