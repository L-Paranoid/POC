(function (win, ysp) {
  ysp.runtime.Model.extendLoadingModel({
    getData_control20_h29MMt: function (elem) {
      if (!elem) {
        elem = elem.ownerDocument;if (!elem) {
          return false;
        }
      }return 'OK';
    },
    doAction_uiControl12_LG4GHo: function (data, elem) {
      if (data.eventType == 'change') {
        var idx = data.dataCustom;var target = elem.ownerDocument.querySelectorAll('.ListWrapper')[1].querySelectorAll('div')[idx];var evt = target.ownerDocument.createEvent('MouseEvents');evt.initEvent('mousedown', true);target.dispatchEvent(evt);
      }
    },
    getTemplate_uiControl12_LG4GHo: function () {
      var selfTemplate = "module.exports = React.createClass({\n  onchange:function(e){\n    var target=e.target;\n    var handler=this.props.customHandler;\n    if(handler){\n      handler({\n        eventType:'change',\n        data:target.selectedIndex\n      })\n    }\n  },\n  render: function() {\n    var data=[1,2,3,4,5,6,7,8,9,10,11,12];\n    var opts=data.map(function(opt,optid){\n      return(\n      \t\t<option>{opt}</option>\n      )\n    })\n    return (\n      <div>\n        <select onChange={this.onchange}>\n        \t{opts}\n        </select>\n      </div>\n    )\n  }\n});";
      return '\'use strict\';\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  onchange: function onchange(e) {\n    var target = e.target;\n    var handler = this.props.customHandler;\n    if (handler) {\n      handler({\n        eventType: \'change\',\n        data: target.selectedIndex\n      });\n    }\n  },\n  render: function render() {\n    var data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];\n    var opts = data.map(function (opt, optid) {\n      return React.createElement(\n        \'option\',\n        null,\n        opt\n      );\n    });\n    return React.createElement(\n      \'div\',\n      null,\n      React.createElement(\n        \'select\',\n        { onChange: this.onchange },\n        opts\n      )\n    );\n  }\n});';
    },
    getData_control49_LQ6gCE: function (elem) {},
    doAction_uiControl44_LDbuXB: function (data, elem) {},
    getTemplate_uiControl44_LDbuXB: function () {
      var selfTemplate = 'module.exports = React.createClass({\n  render: function() {\n    return (\n      <div className=\'changeMouth\'>\n       <span>\u8BF7\u9009\u62E9\u6708\u4EFD</span>\n      </div>\n    )\n  }\n});';
      return '\'use strict\';\n\nmodule.exports = React.createClass({\n  displayName: \'exports\',\n\n  render: function render() {\n    return React.createElement(\n      \'div\',\n      { className: \'changeMouth\' },\n      React.createElement(\n        \'span\',\n        null,\n        \'\\u8BF7\\u9009\\u62E9\\u6708\\u4EFD\'\n      )\n    );\n  }\n});';
    },
    getData_control51_377LqT: function (elem) {
      if (!elem) {
        return false;
      }var data = elem.ownerDocument.querySelectorAll('.inputMask')[0].className;return data;
    },
    doAction_uiControl46_lOpdAZ: function (data, elem) {},
    getTemplate_uiControl46_lOpdAZ: function () {
      var selfTemplate = "module.exports = React.createClass({\n  render: function() {\n    if(!this.props.customData){\n      return(\n     \t <div></div>\n      )\n    }else{\n      return (\n      <div>\n        \n      </div>\n    )\n    }\n  }\n});";
      return "\"use strict\";\n\nmodule.exports = React.createClass({\n  displayName: \"exports\",\n\n  render: function render() {\n    if (!this.props.customData) {\n      return React.createElement(\"div\", null);\n    } else {\n      return React.createElement(\"div\", null);\n    }\n  }\n});";
    }
  });
})(window, ysp);